<?php

namespace app\common\model;

use think\Model;

class Organizational extends Model
{

}
<?php

namespace app\common\model;

use think\Model;

class AdminLog extends Model
{
    protected $name = 'admin_log1';

}
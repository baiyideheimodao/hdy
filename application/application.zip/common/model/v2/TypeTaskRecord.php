<?php
    /**
     *  Encoding : UTF-8
     *  Separator : Unix and OS X (\n)
     *  File Name : TypeTaskRecord.php
     *  Create Date : 2022/5/22 14:01
     *  Version : 0.1
     *  Copyright : skylong Project Team Copyright (C)
     *  license http://creativecommons.org/licenses/by-nc-sa/4.0/deed.zh
     */
    namespace app\common\model\v2;
    use think\Model;

    class TypeTaskRecord extends Model {

        protected $name = 'type_tasks_record';
    }
<?php
    /**
     *  Author : Dream <34650064@QQ.com>
     *  Encoding : UTF-8
     *  Separator : Unix and OS X (\n)
     *  File Name : Task.php
     *  Create Date : 2022/5/22 14:11
     *  Version : 0.1
     *  Copyright : skylong Project Team Copyright (C)
     *  Email Address : yxly330@126.com
     *  license http://creativecommons.org/licenses/by-nc-sa/4.0/deed.zh
     */
    namespace app\common\model\v2;
    use think\Model;

    class Task extends Model {

        protected $name = 'task';
    }
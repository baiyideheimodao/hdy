<?php


namespace app\common\model;


use think\Model;

class UserTypeTaskTable extends Model
{

}
<?php


namespace app\admin\model;


use think\route\dispatch\Controller;

class System extends Controller
{

}
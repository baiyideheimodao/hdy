<?php
    /**
     *  Author : Dream <34650064@QQ.com>
     *  Encoding : UTF-8
     *  Separator : Unix and OS X (\n)
     *  File Name : Message.php
     *  Create Date : 2021/12/31 10:50
     *  Version : 0.1
     *  Copyright : skylong Project Team Copyright (C)
     *  Email Address : yxly330@126.com
     *  license http://creativecommons.org/licenses/by-nc-sa/4.0/deed.zh
     */

    namespace app\admin\model;
    use think\Model;

    class Message extends Model {

        protected $name = 'message';

        public function addMsg(){

        }
    }